
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Database class for establishing connection
 */
public class db {
    
    public static Connection mycon() {
        try {
            // Register the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Establish connection
            Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/login", "root", "");
            
            return c;
        } catch (ClassNotFoundException | SQLException e) {
            // Handle exceptions
            e.printStackTrace();
        }
        return null;
    }
}