package Login;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Database class for establishing connection
 */
public class db {
    
    public static Connection mycon() {
        try {
            System.out.println("21");
            // Register the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("22");
            // Establish connection
            Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/login", "root", "");
            System.out.println("23");
            return c;
        } catch (ClassNotFoundException | SQLException e) {
            // Handle exceptions
            e.printStackTrace();
        }
        return null;
    }
}