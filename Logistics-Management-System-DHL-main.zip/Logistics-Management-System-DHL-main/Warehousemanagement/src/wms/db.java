/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package wms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author kavin
 */
public class db {

    static Connection con = null;

    public static Connection mycon() throws SQLException {

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/Warehouse_Management", "root", "");

            return con;

        } catch (ClassNotFoundException | SQLException e) { // Log or handle the specific exception
            // Print the stack trace for debugging purposes
            throw new SQLException("Failed to connect to the database: " + e.getMessage());
        }

    }

}
