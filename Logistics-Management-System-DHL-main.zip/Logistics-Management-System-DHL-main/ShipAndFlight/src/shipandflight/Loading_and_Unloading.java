package shipandflight;

import com.mysql.cj.protocol.Resultset;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;

public class Loading_and_Unloading extends javax.swing.JFrame {

    public Loading_and_Unloading() {
        
        initComponents();
        }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        t_sd = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        t_sc = new javax.swing.JTextArea();
        t_weight = new javax.swing.JTextField();
        t_date = new javax.swing.JTextField();
        t_oid = new javax.swing.JTextField();
        t_sn = new javax.swing.JTextField();
        t_dc = new javax.swing.JTextField();
        t_co = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Order ID", "Manifest Date", "Country of Origin", "Destination Country", "Shipment Number", "Weight", "Storage Conditions"
            }
        ));
        jScrollPane3.setViewportView(jTable2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/photos/Loading_1.jpg"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1080, -1));

        jPanel2.setBackground(new java.awt.Color(0, 102, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setText("Loading / Unloading");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 190, -1, -1));

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));

        jLabel9.setBackground(new java.awt.Color(153, 153, 153));
        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel9.setText("Order ID ");

        jLabel8.setBackground(new java.awt.Color(153, 153, 153));
        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel8.setText("Manifest Date");

        jLabel7.setBackground(new java.awt.Color(153, 153, 153));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel7.setText("Country of Origin");

        jLabel6.setBackground(new java.awt.Color(153, 153, 153));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setText("Destination Country");

        jLabel5.setBackground(new java.awt.Color(153, 153, 153));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setText("Shipment Number");

        jLabel4.setBackground(new java.awt.Color(153, 153, 153));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setText("Weight");

        jLabel10.setBackground(new java.awt.Color(153, 153, 153));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setText("Storage Conditions");

        jLabel3.setBackground(new java.awt.Color(153, 153, 153));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setText("Shipment Date");

        t_sd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_sdActionPerformed(evt);
            }
        });

        t_sc.setColumns(20);
        t_sc.setRows(5);
        jScrollPane1.setViewportView(t_sc);

        t_weight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_weightActionPerformed(evt);
            }
        });

        t_date.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_dateActionPerformed(evt);
            }
        });

        t_oid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_oidActionPerformed(evt);
            }
        });

        t_sn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_snActionPerformed(evt);
            }
        });

        t_dc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_dcActionPerformed(evt);
            }
        });

        t_co.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_coActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(131, 131, 131)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel10)
                    .addComponent(jLabel4)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7))
                .addGap(54, 54, 54)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(t_co, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_dc, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_sn, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_oid, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_date, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_weight, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_sd, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(118, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(t_oid))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(t_date, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(t_co, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(t_dc, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(6, 6, 6)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(t_sn, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(t_weight, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(t_sd, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(0, 50, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 190, 880, 410));

        jButton8.setBackground(new java.awt.Color(255, 204, 0));
        jButton8.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton8.setText("REFRESH");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 630, 170, 40));

        jButton7.setBackground(new java.awt.Color(255, 204, 0));
        jButton7.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton7.setText("UPDATE");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 630, 160, 40));

        jButton5.setBackground(new java.awt.Color(255, 204, 0));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton5.setText("VIEW");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 630, 120, 40));

        jButton1.setBackground(new java.awt.Color(255, 204, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setText("ADD DATA");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 630, 190, 40));

        jButton2.setBackground(new java.awt.Color(0, 255, 255));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton2.setText("Loading / Unloading");
        jButton2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 120, 220, 50));

        jButton3.setBackground(new java.awt.Color(255, 204, 0));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton3.setText("Check Email");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 120, 220, 50));

        jButton4.setBackground(new java.awt.Color(255, 204, 0));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton4.setText("Reports");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 120, 210, 50));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 730));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 730));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void t_dateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_dateActionPerformed
         //Manifest Date text field       
    }//GEN-LAST:event_t_dateActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
         //Add Data button action
        
         String OrderID = t_oid.getText();
         String ManifestDate = t_date.getText();
         String CountryofOrigin = t_co.getText();
         String DestinationCountry = t_dc.getText();
         String ShipmentNumber = t_sn.getText();
         String Weight = t_weight.getText();
         String StorageConditions = t_sc.getText();
         String ShipmentDate = t_sd.getText();
    
    // Validation for null values
    if (OrderID.isEmpty() || ManifestDate.isEmpty() || CountryofOrigin.isEmpty() || DestinationCountry.isEmpty() || ShipmentNumber.isEmpty() || Weight.isEmpty() || StorageConditions.isEmpty() || ShipmentDate.isEmpty()) {
        JOptionPane.showMessageDialog(null, "All fields must be filled out.");
        return; // Exit the method if validation fails
    }
    
    // Validation for Order ID (10 digits)
    if (!OrderID.matches("\\d{10}")) {
        JOptionPane.showMessageDialog(null, "Order ID must be exactly 10 digits long.");
        return; // Exit the method if validation fails
    }

    // Validation for Country of Origin and Destination Country (first letter capital)
    if (!CountryofOrigin.matches("[A-Z][a-z]*")) {
        JOptionPane.showMessageDialog(null, "Country of Origin must start with a capital letter and contain only letters.");
        return; // Exit the method if validation fails
    }

    if (!DestinationCountry.matches("[A-Z][a-z]*")) {
        JOptionPane.showMessageDialog(null, "Destination Country must start with a capital letter and contain only letters.");
        return; // Exit the method if validation fails
    }
    
    // Validation for Shipment Number (10 characters, first two letters, rest digits)
    if (!ShipmentNumber.matches("[a-zA-Z]{2}\\d{8}")) {
        JOptionPane.showMessageDialog(null, "Shipment Number must be exactly 10 characters long with first two letters and rest digits.");
        return; // Exit the method if validation fails
    }
    
    // Validation for order ID (should not be negative)
    if (Integer.parseInt(OrderID) < 0) {
        JOptionPane.showMessageDialog(null, "Order ID cannot be negative.");
        return; // Exit the method if validation fails
    }

    // Validation for weight (should be a positive number)
    try {
        double weightValue = Double.parseDouble(Weight);
        if (weightValue <= 0) {
            JOptionPane.showMessageDialog(null, "Weight should be a positive number.");
            return; // Exit the method if validation fails
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Weight should be a valid number.");
        return; // Exit the method if validation fails
    }
    
    // Validation to check if country of origin and destination country are different
    if (CountryofOrigin.equalsIgnoreCase(DestinationCountry)) {
        JOptionPane.showMessageDialog(null, "Country of origin and destination country cannot be the same.");
        return; // Exit the method if validation fails
    }
    
         View_Table View_TableFrame = new View_Table();
         View_TableFrame.setVisible(true);
         View_TableFrame.pack();
         View_TableFrame.setLocationRelativeTo(null);
         this.dispose();    
        
    try {
        Connection con = db.mycon();
        String checkQuery = "SELECT * FROM ship_and_flight_db.order_details WHERE OrderID = ?";
        PreparedStatement checkStatement = con.prepareStatement(checkQuery);
        checkStatement.setString(1, OrderID);
        ResultSet rs = checkStatement.executeQuery();

        if (rs.next()) {
            JOptionPane.showMessageDialog(null, "Order ID already exists. Please choose a different one.");
            return; // Exit the method if Order ID already exists
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error occurred while checking Order ID: " + e.getMessage());
        return; // Exit the method if an error occurs during database query
    }


    try {
        System.out.println("3");
        Connection con = db.mycon();
        System.out.println("4");
        String sql = "INSERT INTO ship_and_flight_db.order_details(OrderID, ManifestDate, CountryofOrigin, DestinationCountry, ShipmentNumber, Weight, StorageConditions,ShipmentDate) values(?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement pst = con.prepareStatement(sql);
        System.out.println("5");

        pst.setString(1, OrderID);
        pst.setString(2, ManifestDate);
        pst.setString(3, CountryofOrigin);
        pst.setString(4, DestinationCountry);
        pst.setString(5, ShipmentNumber);
        pst.setString(6, Weight);
        pst.setString(7, StorageConditions);
        pst.setString(8, ShipmentDate);

        System.out.println("6");

        // Execute the PreparedStatement
        int rowsAffected = pst.executeUpdate();
        System.out.println("Rows affected: " + rowsAffected);

        JOptionPane.showMessageDialog(null, "Data Saved");

    } catch (SQLException e) {
       
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error occurred while saving data: " + e.getMessage());
    }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        //Button Loading and Unloading
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // Button Check Email

        Email EmailFrame = new Email();
        EmailFrame.setVisible(true);
        EmailFrame.pack();
        EmailFrame.setLocationRelativeTo(null);
        this.dispose();

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // Button Reports

        Report ReportFrame = new Report();
        ReportFrame.setVisible(true);
        ReportFrame.pack();
        ReportFrame.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void t_coActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_coActionPerformed
        // Country of Origin text field
    }//GEN-LAST:event_t_coActionPerformed

    private void t_dcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_dcActionPerformed
        // Destination Country text field
    }//GEN-LAST:event_t_dcActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        //Update Button Action
        
        String OrderID = t_oid.getText();
        String ManifestDate = t_date.getText();
        String CountryofOrigin = t_co.getText();
        String DestinationCountry = t_dc.getText();
        String ShipmentNumber = t_sn.getText();
        String Weight = t_weight.getText();
        String StorageConditions = t_sc.getText();
        String ShipmentDate = t_sd.getText();
    
    try {
        // Establish database connection
        Connection con = db.mycon();
        
        // Construct the SQL update statement
        String sql = "UPDATE ship_and_flight_db.order_details SET ManifestDate=?, CountryofOrigin=?, DestinationCountry=?, ShipmentNumber=?, Weight=?, StorageConditions=?, ShipmentDate=? WHERE OrderID=?";
        
        // Create a PreparedStatement
        PreparedStatement pst = con.prepareStatement(sql);
        
        // Set parameters for the update statement
        pst.setString(1, ManifestDate);
        pst.setString(2, CountryofOrigin);
        pst.setString(3, DestinationCountry);
        pst.setString(4, ShipmentNumber);
        pst.setString(5, Weight);
        pst.setString(6, StorageConditions);
        pst.setString(7, OrderID);
        pst.setString(8, ShipmentDate);// Where clause parameter
        
        // Execute the update statement
        int rowsAffected = pst.executeUpdate();
        
        // Check if any rows were affected
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(null, "Data updated successfully.");
        } else {
            JOptionPane.showMessageDialog(null, "Failed to update data. Order ID not found.");
        }
        
        // Close the database connection
        con.close();
    } catch (SQLException e) {
        // Handle any SQL exceptions
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error occurred while updating data: " + e.getMessage());
    }
         
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // View Button Action
        
         try {
        Connection con = db.mycon();
        String sql = "SELECT * FROM ship_and_flight_db.order_details ORDER BY OrderID DESC LIMIT 1 "; 
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        
        if (rs.next()) {
            // Set values from the ResultSet to the text fields
            t_oid.setText(rs.getString("OrderID"));
            t_date.setText(rs.getString("ManifestDate"));
            t_co.setText(rs.getString("CountryofOrigin"));
            t_dc.setText(rs.getString("DestinationCountry"));
            t_sn.setText(rs.getString("ShipmentNumber"));
            t_weight.setText(rs.getString("Weight"));
            t_sc.setText(rs.getString("StorageConditions"));
            t_sd.setText(rs.getString("ShipmentDate"));
        } else {
            JOptionPane.showMessageDialog(null, "No data found in the database.");
        }
        
        con.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error occurred while retrieving data: " + e.getMessage());
    }
         
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // Refresh Button Action
        t_oid.setText("");
        t_date.setText("");
        t_co.setText("");
        t_dc.setText("");
        t_sn.setText("");
        t_weight.setText("");
        t_sc.setText("");
        t_sd.setText("");
    
    }//GEN-LAST:event_jButton8ActionPerformed

    private void t_sdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_sdActionPerformed
        // Shipment Date text field
    }//GEN-LAST:event_t_sdActionPerformed

    private void t_snActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_snActionPerformed
        // Shipment Number text field
    }//GEN-LAST:event_t_snActionPerformed

    private void t_oidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_oidActionPerformed
        // Order ID text field
    }//GEN-LAST:event_t_oidActionPerformed

    private void t_weightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_weightActionPerformed
        // Weight text field
    }//GEN-LAST:event_t_weightActionPerformed

  
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
        
                new Loading_and_Unloading().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField t_co;
    private javax.swing.JTextField t_date;
    private javax.swing.JTextField t_dc;
    private javax.swing.JTextField t_oid;
    private javax.swing.JTextArea t_sc;
    private javax.swing.JTextField t_sd;
    private javax.swing.JTextField t_sn;
    private javax.swing.JTextField t_weight;
    // End of variables declaration//GEN-END:variables
}
